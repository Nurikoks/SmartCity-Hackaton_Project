import pandas as pd
import os

# === Настройки ===
FILE_PATH = "gis.csv"
SEPARATOR = ";"
ERROR_DIR = "errors"
CLEAN_FILE = "gis_clean.csv"

# === Загрузка ===
try:
    df = pd.read_csv(FILE_PATH, sep=SEPARATOR, dtype=str)
    print(f"✅ Загружено {len(df)} записей")
except Exception as e:
    print(f"❌ Ошибка при загрузке файла: {e}")
    exit()

# === Обязательные поля ===
required_fields = ["Id", "Название", "Город", "Адрес", "Время работы", "Широта", "Долгота"]

# Проверяем наличие всех обязательных колонок
missing_columns = [col for col in required_fields if col not in df.columns]
if missing_columns:
    print(f"❌ В файле отсутствуют обязательные столбцы: {missing_columns}")
    exit()

# === Проверка пропусков ===
mask_missing = df[required_fields].isna() | (df[required_fields].apply(lambda x: x.str.strip() == ""))
rows_with_missing = df[mask_missing.any(axis=1)]

# === Проверяем, что есть хотя бы один телефон ===
no_phone = df[
    (df["Телефон"].fillna("").str.strip() == "") &
    (df["Мобильный телефон"].fillna("").str.strip() == "")
]

# Объединяем все ошибки (пропуски обязательных полей + отсутствие телефона)
all_errors = pd.concat([rows_with_missing, no_phone]).drop_duplicates()
rows_clean = df.drop(all_errors.index)

print(f"⚠️ Найдено {len(all_errors)} записей с пропущенными обязательными полями или без телефона")
print(f"✅ После очистки останется {len(rows_clean)} записей")

# === Папка для ошибок ===
os.makedirs(ERROR_DIR, exist_ok=True)

# === Сохраняем ошибки ===
error_file = os.path.join(ERROR_DIR, "missing_required_fields_or_phone.csv")
if not all_errors.empty:
    all_errors.to_csv(error_file, sep=";", index=False, encoding="utf-8-sig")
    print(f"❌ Ошибочные строки сохранены в: {error_file}")

# === Сохраняем чистый файл ===
rows_clean.to_csv(CLEAN_FILE, sep=";", index=False, encoding="utf-8-sig")
print(f"✅ Очищенный файл сохранён как: {CLEAN_FILE}")

# === Детальный отчёт ===
print("\n📋 Детальный отчёт по пропускам:")
for col in required_fields + ["Телефон", "Мобильный телефон"]:
    count_missing = (df[col].isna() | (df[col].fillna("").str.strip() == "")).sum()
    print(f" - {col}: {count_missing}")

print("\n🎯 Готово! Файл gis_clean.csv содержит только корректные записи.")
